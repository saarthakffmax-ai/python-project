
from rest_framework import generics
from .models import Student
from .serializers import StudentSerializer
from django_filters.rest_framework import DjangoFilterBackend

class StudentListCreate(generics.ListCreateAPIView):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['age']
