
import requests
from bs4 import BeautifulSoup

url = "https://www.w3schools.com/html/html_tables.asp"
soup = BeautifulSoup(requests.get(url).text, "html.parser")

table = soup.find("table")
for row in table.find_all("tr"):
    data = [cell.text for cell in row.find_all(["td","th"])]
    print(data)
