
import requests
from bs4 import BeautifulSoup

url = "https://example.com"
soup = BeautifulSoup(requests.get(url).text, "html.parser")

links = soup.find_all("a")
for link in links:
    print(link.get("href"))
