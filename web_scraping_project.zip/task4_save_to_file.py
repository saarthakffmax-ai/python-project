
import requests
from bs4 import BeautifulSoup

url = "https://example.com"
soup = BeautifulSoup(requests.get(url).text, "html.parser")

with open("headings.txt", "w") as f:
    for h in soup.find_all("h1"):
        f.write(h.text + "\n")

print("Data saved to headings.txt")
